__author__ = 'cmaran'

class Human(object):

    def __init__(self):
        self.name = "Human"
    def speak(self):
        return "'hello'"