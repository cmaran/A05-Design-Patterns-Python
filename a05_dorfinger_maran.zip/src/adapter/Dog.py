__author__ = 'cmaran'

class Dog(object):

    def __init__(self):
        self.name = "Dog"

    def bark(self):
        return "woof!"