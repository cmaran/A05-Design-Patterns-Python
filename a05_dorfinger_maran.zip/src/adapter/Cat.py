__author__ = 'cmaran'

class Cat(object):

    def __init__(self):
        self.name = "Cat"

    def meow(self):
        return "meow!"