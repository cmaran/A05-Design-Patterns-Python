__author__ = 'cmaran'

class Square:

    def __str__(self):
        return "Square"