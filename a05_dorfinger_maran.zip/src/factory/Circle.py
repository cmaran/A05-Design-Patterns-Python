__author__ = 'cmaran'

class Circle:

    def __str__(self):
        return "Circle"