Singleton-Class
========

Singleton
------------

.. py:currentmodule:: singleton.Singleton
.. autoclass:: Singleton
	:members:
	
..autofunction:: __init__

---------------------------------------------

..autofunction:: __call__




