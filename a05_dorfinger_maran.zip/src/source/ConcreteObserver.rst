ConcreteObserver-Class
========

ConcreteObserver
------------

.. py:currentmodule:: observer.Observer
.. autoclass:: ConcreteObserver
	:members:
	
..autofunction:: __init__




