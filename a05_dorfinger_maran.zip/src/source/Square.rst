Square-Class
========

Square
------------

.. py:currentmodule:: factory.Square
.. autoclass:: Square
	:members:
	
..autofunction:: __str__




