Dog-Class
========

Dog
------------

.. py:currentmodule:: adapter.Dog
.. autoclass:: Dog
	:members:
	
..autofunction:: __init__



