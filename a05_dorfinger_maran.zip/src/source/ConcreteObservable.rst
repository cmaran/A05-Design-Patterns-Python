Observer-Class
========

Observer
------------

.. py:currentmodule:: observer.Observable
.. autoclass:: ConcreteObservable
	:members:
	
..autofunction:: __init__




