Adapter Pattern
========

Adapter Pattern
------------

.. py:currentmodule:: adapter.Adapter
.. autoclass:: Adapter
	:members:
	
..autofunction:: __init__

---------------------------------------------

..autofunction:: __getattr__

