.. A05-Design Patterns documentation master file, created by
   sphinx-quickstart on Mon Dec 22 12:58:09 2014.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to A05-Design Patterns's documentation!
===============================================

Contents:

.. toctree::
   :maxdepth: 2
		Decorator.rst
		Adapter.rst
		Dog.rst
		Cat.rst
		Car.rst
		Human.rst
		Factory.rst
		CircleFactory.rst
		SquareFactory.rst
		Circle.rst
		Square.rst
		Singleton.rst
		SingletonTest.rst
		TestObserver.rst
		Observer.rst
		Observable.rst
		ConcreteObservable.rst
		ConcreteObserver.rst


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

