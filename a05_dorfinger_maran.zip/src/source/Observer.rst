Observer-Class
========

Observer
------------

.. py:currentmodule:: observer.Observer
.. autoclass:: ConcreteObserver
	:members:
	
..autofunction:: __init__




