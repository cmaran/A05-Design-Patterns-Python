SquareFactory-Class
========

SquareFactory
------------

.. py:currentmodule:: factory.Square
.. autoclass:: Square
	:members:
	





