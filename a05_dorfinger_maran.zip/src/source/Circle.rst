Circle-Class
========

Circle
------------

.. py:currentmodule:: factory.Circle
.. autoclass:: Circle
	:members:
	
..autofunction:: __str__




