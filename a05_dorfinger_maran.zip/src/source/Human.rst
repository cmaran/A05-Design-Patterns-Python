Human-Class
========

Human
------------

.. py:currentmodule:: adapter.Human
.. autoclass:: Human
	:members:
	
..autofunction:: __init__




