Factory-Class
========

Factory
------------

.. py:currentmodule:: factory.Factory
.. autoclass:: ShapeCreator
	:members:
	
..autofunction:: __init__




