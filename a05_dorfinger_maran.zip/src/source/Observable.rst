Observable-Class
========

Observable
------------

.. py:currentmodule:: observer.Observable
.. autoclass:: Observable
	:members:
	
..autofunction:: __init__




