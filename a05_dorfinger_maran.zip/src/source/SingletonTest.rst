SingletonTest-Class
========

SingletonTest
------------

.. py:currentmodule:: singleton.SingletonTest
.. autoclass:: SingletonTest
	:members:
	
..autofunction:: __init__




