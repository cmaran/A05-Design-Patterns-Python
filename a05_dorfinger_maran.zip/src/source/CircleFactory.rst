CircleFactory-Class
========

CircleFactory
------------

.. py:currentmodule:: factory.CircleFactory
.. autoclass:: CircleFactory
	:members:
	





