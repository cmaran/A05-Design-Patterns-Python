Decorator Pattern
========

Decorator Class
------------

.. py:currentmodule:: decorator.Decorator
.. autoclass:: Student
	:members:

---------------------------------------------
	
..autofunction:: __init__




