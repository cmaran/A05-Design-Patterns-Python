Cat-Class
========

Cat
------------

.. py:currentmodule:: adapter.Cat
.. autoclass:: Cat
	:members:
	
..automethod:: __init__



